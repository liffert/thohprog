#pragma once



void E_start();
inline void E_create_menu();
inline void Al_sum();
inline void Al_sum_pow_i();
inline void Big_and_small();
inline void angle();
inline void step();
inline void week_day();
inline void vec_len();
inline void Func_without_pow();
inline void sum_big_then();
inline void func2();
inline void MY_RAND();
void koord();
void equ_digits();
void str_count();
inline void Brick();
inline void rhombus();
inline void str_k();
void Hex();
void Palindrom();
void ctg_func();
void test();
void slid_matrix();
void avarage();
void sin_func();
void  per5();
void kvad_table();
void mult_num();
void Intersection_points();
void integer();
void use_do_while_sorry_GOD();
void fuck_editors();
void triangles();