#pragma once

void B_start();
inline void B_create_menu();
inline void num_to_digits();
inline void math_sentense();
inline void to_up();
inline void metre_to_km();
inline void print();
inline void print_house();
inline void print_triangle();
inline void print_ramka();
inline void compare();
void if_increase();