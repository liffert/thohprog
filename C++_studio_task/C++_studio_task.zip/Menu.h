#pragma once
#include <iostream>
#include <vector>
#include "progbase/console.h"

class Menu {

public:
    Menu();
    void set_func(void (*func)(void), std::string name); 
    void start();
    void set_last_text(std::string name);
    void clear();
    void set_headline(std::string head);
    ~Menu();
private:
    struct map{
        void (*func)(void);
        std::string name;
    };
    std::vector<map> func_map;
    int count = 0;
    std::string *names;
    std::string Headline = "";
    std::string last = "Exit";

    void draw_menu(int selection);
    void set_names_array(std::string *names);
    std::string get_name(int i);

    double return_value;
};