#include "Menu.h"

Menu::Menu(){};

Menu::~Menu(){};

void Menu::set_func(void (*func)(void), std::string name){
    struct map temp;
    temp.func = func;
    temp.name = name;
    func_map.push_back(temp);
}

void Menu::start(){
    int selection = 0;
    count = func_map.size();
    names = new std::string[count + 1];
    set_names_array(names);
    count++;
    while(1){
        draw_menu(selection);
        int key = Console_getChar();
        switch(key){
            case 91: {
                int key_next = Console_getChar();
                if(key_next == 66 && selection < count - 1){
                    selection++;
                }
                else if(key_next == 65 && selection > 0){
                    selection--;
                }
                break;
            }
            case 10: {
                if(selection == count - 1){
                    if(last != "Exit"){
                        return;
                    }
                    else{
                        Console_clear();
                        exit(true);
                    }
                }
                else{
                    Console_clear();
                    func_map[selection].func();
                }
                break;
            }
        }
    }
}

void Menu::draw_menu (int selection){
    Console_clear();
    Console_setCursorPosition(8, 30);
    std::cout << Headline;
    for(int i = 0; i < count; i++){
        Console_setCursorPosition(10 + i, 30);
        if(i == selection){
            printf("<%d.%s>", i + 1, names[i].c_str());
        }
        else{
            printf("%d.%s", i + 1, names[i].c_str());
        }
    }
}

void Menu::set_names_array (std::string *names){
    for(int i = 0; i < count; i++){
        names[i] = get_name(i);
    }
    names[count] = last;
}

std::string Menu::get_name (int i){
    return func_map[i].name;
}

void Menu::set_last_text(std::string name){
    last = name;
}
void Menu::clear(){
    last = "Exit";
    func_map.clear();
    count = 0;
}
void Menu::set_headline(std::string head){
    Headline = head;
}